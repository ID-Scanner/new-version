package com.example.jersey.entities;

public enum TypeCompte {
    COURANT,EPARGNE
}
